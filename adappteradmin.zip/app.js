const createError     = require('http-errors');
const express         = require('express');
const session         = require('express-session');
const express_file    = require('express-fileupload');
const flash           = require('connect-flash');

const passport        = require('passport');
const path            = require('path');
const cookieParser    = require('cookie-parser');
const morgan          = require('morgan');
const schedule        = require('./library/schedule/schedule')

const passportConfig  = require('./library/passport/passport')

const indexRouter     = require('./routes/index');
const settingRouter   = require('./routes/setting');
const seasonRouter    = require('./routes/season');
const questionRouter  = require('./routes/question');
const userRouter      = require('./routes/user');
const liveNewsRouter  = require('./routes/livenews');
const statisticsRouter  = require('./routes/statistics');
const tradeRouter     = require('./routes/trade');
const paymentRouter   = require('./routes/payment');
const communityRouter = require('./routes/community');
const giftRouter      = require('./routes/gift');
const quizRouter      = require('./routes/quiz');

const app             = express();

app.set('views'       , path.join(__dirname, 'views'));
app.set('view engine' , 'pug');

app.use(morgan('dev'));
app.use(express.json());
app.use(express.urlencoded({ extended: false }));
app.use(cookieParser());
app.use(express_file({
  useTempFiles : true,
  tempFileDir : '/tmp/'
}));
app.use(express.static(path.join(__dirname, 'public')));
app.use(express.static(path.join(__dirname, 'components')));
app.use(
  session({
    secret: 'SDSF@@#FDKJSDKLJLSFNSV@@',
    resave: false,
    saveUninitialized: true,
    maxAge: null
  })
);


app.use(passport.initialize())
app.use(passport.session())
app.use(flash());

passportConfig();

app.use('/'         , indexRouter);
app.use('/setting'  , settingRouter);
app.use('/season'   , seasonRouter);
app.use('/question' , questionRouter);
app.use('/user'     , userRouter);
app.use('/livenews' , liveNewsRouter);
app.use('/statistics' , statisticsRouter);
app.use('/trade'    , tradeRouter);
app.use('/payment'  , paymentRouter);
app.use('/community', communityRouter);
app.use('/gift'     , giftRouter);
app.use('/quiz'     , quizRouter);

schedule.runSchedule()

app.use( (req, res, next) => {
  next( (404));
});

app.use( (err, req, res) => {
  res.locals.message  = err.message;
  res.locals.error    = req.app.get('env') === 'development' ? err : {};

  res.status(err.status || 500);
  res.render('error');
});

module.exports = app;